v0.0.5
------
* Applies backport of CHEF-3164 to _all_ versions under 10.14.0 (thanks [cgriego](https://github.com/cgriego))

v0.0.4
------
* Backports CHEF-3164 (thanks [cgriego](https://github.com/cgriego))

v0.0.3
------
* Default node in overrides if it is unavailable

v0.0.2
------
* Add omnibus fixes for installs < 0.10.12
* Add conditional patching based on chef version

v0.0.1
------
* Initial release
