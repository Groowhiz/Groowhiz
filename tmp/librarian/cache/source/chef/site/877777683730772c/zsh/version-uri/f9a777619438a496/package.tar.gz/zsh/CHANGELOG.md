## v1.0.1

* Add name attribute to metadata (for Chef 12)

## v1.0.0

* Improvements to toplevel files, docs, test harness, etc.

## v0.7.1

* Current public release.
